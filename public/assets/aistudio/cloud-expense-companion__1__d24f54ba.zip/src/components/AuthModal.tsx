import React, { useState } from 'react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  googleProvider, 
  microsoftProvider,
  appleProvider,
  sendPasswordResetEmail,
  sendEmailVerification,
  auth,
  getFriendlyAuthErrorMessage
} from '../lib/firebase';
import { 
  X, 
  LogIn, 
  UserPlus, 
  AlertCircle, 
  CheckCircle2, 
  KeyRound, 
  ShieldCheck, 
  ShieldAlert,
  Mail, 
  Lock, 
  ArrowLeft,
  ChevronRight,
  Info
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onAdminSuccess?: () => void;
  initialMode?: 'signin' | 'register' | 'forgot_password' | 'admin';
}

type AuthMode = 'signin' | 'register' | 'forgot_password' | 'admin';

export const AuthModal: React.FC<Props> = ({ 
  isOpen, 
  onClose,
  onAdminSuccess,
  initialMode = 'signin' 
}) => {
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [adminPasskey, setAdminPasskey] = useState('');
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const resetMessages = () => {
    setError('');
    setSuccessMsg('');
  };

  const handleModeSwitch = (newMode: AuthMode) => {
    resetMessages();
    setMode(newMode);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    // Administrator Authentication Route
    if (mode === 'admin') {
      if (!adminPasskey) {
        setError('Please enter the administrator security credential.');
        return;
      }
      setLoading(true);
      try {
        const res = await fetch('/api/admin/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            email: email || 'admin@expensecompanion.internal', 
            passkey: adminPasskey 
          }),
        });

        const data = await res.json();
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Administrator authentication failed. Unauthorized credentials.');
        }

        sessionStorage.setItem('admin_token', data.token);
        setSuccessMsg('Administrator credentials verified.');
        setTimeout(() => {
          onClose();
          if (onAdminSuccess) {
            onAdminSuccess();
          }
        }, 600);
      } catch (err: any) {
        setError(err.message || 'Administrator authorization failed.');
      } finally {
        setLoading(false);
      }
      return;
    }

    // Normal User Registration Checks
    if (mode === 'register') {
      if (password.length < 6) {
        setError('Password must be at least 6 characters long.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match. Please verify.');
        return;
      }
    }

    setLoading(true);

    try {
      if (mode === 'signin') {
        await signInWithEmailAndPassword(auth, email, password);
        onClose();
      } else if (mode === 'register') {
        const userCred = await createUserWithEmailAndPassword(auth, email, password);
        if (userCred.user) {
          try {
            await sendEmailVerification(userCred.user);
            setSuccessMsg('Account created successfully! A verification email was dispatched to your address.');
          } catch {
            setSuccessMsg('Account created successfully!');
          }
        }
        setTimeout(() => {
          onClose();
        }, 1500);
      } else if (mode === 'forgot_password') {
        await sendPasswordResetEmail(auth, email);
        setSuccessMsg(`Password recovery instructions dispatched to ${email}. Please check your inbox.`);
      }
    } catch (err: any) {
      setError(getFriendlyAuthErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleProviderSignIn = async (provider: 'google' | 'microsoft' | 'apple') => {
    resetMessages();
    setLoading(true);

    try {
      if (provider === 'google') {
        await signInWithPopup(auth, googleProvider);
        onClose();
      } else if (provider === 'microsoft') {
        await signInWithPopup(auth, microsoftProvider);
        onClose();
      } else if (provider === 'apple') {
        await signInWithPopup(auth, appleProvider);
        onClose();
      }
    } catch (err: any) {
      const friendly = getFriendlyAuthErrorMessage(err);
      if (err?.code === 'auth/operation-not-allowed') {
        setError(`${provider.toUpperCase()} Sign-In is not currently enabled in cloud auth. You can sign in using Google or Email/Password.`);
      } else {
        setError(friendly);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="auth-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl max-h-[92vh] overflow-y-auto scrollbar-thin">
        {/* Header Bar */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center space-x-2.5">
            <div className={`p-2 rounded-2xl ${
              mode === 'admin' 
                ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400' 
                : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
            }`}>
              {mode === 'admin' ? <ShieldAlert className="w-5 h-5" /> : <KeyRound className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                {mode === 'signin' && 'Sign In to Account'}
                {mode === 'register' && 'Create Free Account'}
                {mode === 'forgot_password' && 'Reset Password'}
                {mode === 'admin' && 'Administrator Portal Login'}
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {mode === 'signin' && 'Access and sync your cross-device personal finances'}
                {mode === 'register' && 'Start tracking personal expenses with cloud backup'}
                {mode === 'forgot_password' && 'Enter your email to receive recovery instructions'}
                {mode === 'admin' && 'Restricted gateway: Verified administrator role claims required'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher for Sign In / Register (Only in normal user mode) */}
        {mode !== 'forgot_password' && mode !== 'admin' && (
          <div className="flex p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl mb-5 border border-slate-200/60 dark:border-slate-700/60">
            <button
              type="button"
              onClick={() => handleModeSwitch('signin')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                mode === 'signin'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Personal Sign In
            </button>
            <button
              type="button"
              onClick={() => handleModeSwitch('register')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                mode === 'register'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Register
            </button>
          </div>
        )}

        {/* Back to sign in link for password reset or admin login */}
        {(mode === 'forgot_password' || mode === 'admin') && (
          <button
            type="button"
            onClick={() => handleModeSwitch('signin')}
            className="inline-flex items-center space-x-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline mb-4 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Personal User Sign In</span>
          </button>
        )}

        {/* Status Alerts */}
        {error && (
          <div className="mb-4 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 flex items-start space-x-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600 dark:text-rose-400" />
            <div className="space-y-1">
              <span className="font-semibold block">Authentication Notice</span>
              <p className="text-[11px] leading-relaxed">{error}</p>
            </div>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-800 dark:text-emerald-200 flex items-start space-x-2.5">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
            <div className="space-y-1">
              <span className="font-semibold block">Success</span>
              <p className="text-[11px] leading-relaxed">{successMsg}</p>
            </div>
          </div>
        )}

        {/* OAuth Buttons Section (Only on Normal Sign In or Register) */}
        {mode !== 'forgot_password' && mode !== 'admin' && (
          <div className="space-y-2.5 mb-5">
            {/* Google Sign-In */}
            <button
              type="button"
              disabled={loading}
              onClick={() => handleProviderSignIn('google')}
              className="w-full py-2.5 px-4 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800/90 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-2xl transition-all cursor-pointer flex items-center justify-center space-x-2.5 shadow-2xs hover:shadow-xs active:scale-98"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Continue with Google</span>
            </button>

            {/* Microsoft & Apple Sign-In */}
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                disabled={loading}
                onClick={() => handleProviderSignIn('microsoft')}
                className="py-2.5 px-3 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800/90 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-2xl transition-all cursor-pointer flex items-center justify-center space-x-2 shadow-2xs hover:shadow-xs active:scale-98"
                title="Sign in with Microsoft Entra / Outlook / Office365"
              >
                <svg className="w-3.5 h-3.5" viewBox="0 0 23 23">
                  <path fill="#f35325" d="M1 1h10v10H1z" />
                  <path fill="#81bc06" d="M12 1h10v10H12z" />
                  <path fill="#05a6f0" d="M1 12h10v10H1z" />
                  <path fill="#ffba08" d="M12 12h10v10H12z" />
                </svg>
                <span>Microsoft</span>
              </button>

              <button
                type="button"
                disabled={loading}
                onClick={() => handleProviderSignIn('apple')}
                className="py-2.5 px-3 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800/90 hover:bg-slate-50 dark:hover:bg-slate-750 border border-slate-200 dark:border-slate-700 rounded-2xl transition-all cursor-pointer flex items-center justify-center space-x-2 shadow-2xs hover:shadow-xs active:scale-98"
                title="Sign in with Apple ID"
              >
                <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 170 170">
                  <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.04-7.67-7.81-11.96-14.34-5.77-8.91-10.28-18.9-13.53-29.96-3.25-11.06-4.88-21.73-4.88-32.03 0-14.34 3.73-26.33 11.19-35.96 7.46-9.63 16.71-14.54 27.75-14.75 4.35 0 9.4 1.14 15.15 3.42 5.75 2.28 9.58 3.47 11.51 3.56 1.48 0 5.43-1.24 11.85-3.73 6.42-2.48 11.83-3.6 16.24-3.35 12.08.65 22.05 4.96 29.91 12.93-10.55 6.42-15.7 15.44-15.46 27.07.24 9.14 3.74 16.91 10.5 23.3 6.76 6.39 14.88 10.05 24.36 10.98-2.16 6.53-4.78 13.11-7.86 19.74zM119.22 31.84c0-7.18 2.6-13.84 7.8-19.98 5.2-6.14 11.66-9.92 19.38-11.36.43 3.48.43 6.64 0 9.47-.85 7.18-3.7 13.79-8.54 19.83-4.84 6.04-10.99 9.87-18.45 11.48-.19-.48-.19-1.95-.19-9.44z" />
                </svg>
                <span>Apple</span>
              </button>
            </div>

            <div className="relative my-3">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-200 dark:border-slate-800" />
              </div>
              <div className="relative flex justify-center text-[10px] uppercase font-bold tracking-wider">
                <span className="bg-white dark:bg-slate-900 px-3 text-slate-400">or with email credentials</span>
              </div>
            </div>
          </div>
        )}

        {/* Form for Login, Register, or Admin */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {mode === 'admin' ? (
            /* Dedicated Admin Login Form */
            <div className="space-y-3.5">
              <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/60 text-[11px] text-rose-800 dark:text-rose-200">
                <span className="font-bold block mb-0.5">Authorized Personnel Only:</span>
                Log in using your administrator identity and security key. Normal user accounts cannot access administrative metrics or controls.
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Administrator Email / Account ID
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="email"
                    required
                    placeholder="admin@expensecompanion.internal"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Administrator Security Key / Passkey
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••••••"
                    value={adminPasskey}
                    onChange={e => setAdminPasskey(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-hidden focus:ring-2 focus:ring-rose-500 font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-bold text-white bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 rounded-2xl transition-all shadow-md cursor-pointer flex items-center justify-center space-x-2 mt-4 active:scale-98"
              >
                {loading ? (
                  <span>Verifying Credentials...</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Authorize as Administrator</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            /* Normal User Form (Signin / Register / Forgot) */
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="email"
                    required
                    placeholder="you@example.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {mode !== 'forgot_password' && (
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Password
                    </label>
                    {mode === 'signin' && (
                      <button
                        type="button"
                        onClick={() => handleModeSwitch('forgot_password')}
                        className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                      >
                        Forgot password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              )}

              {mode === 'register' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 rounded-2xl transition-all shadow-md cursor-pointer flex items-center justify-center space-x-2 mt-4 active:scale-98"
              >
                {loading ? (
                  <span>Authenticating...</span>
                ) : mode === 'signin' ? (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>Sign In Securely</span>
                  </>
                ) : mode === 'register' ? (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>Create Account & Verify</span>
                  </>
                ) : (
                  <>
                    <Mail className="w-4 h-4" />
                    <span>Send Password Reset Email</span>
                  </>
                )}
              </button>
            </>
          )}
        </form>

        {/* Bottom Gateway Switch to Administrator Portal */}
        {mode !== 'admin' && (
          <div className="mt-5 pt-3.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              System Administrator?
            </span>
            <button
              type="button"
              onClick={() => handleModeSwitch('admin')}
              className="text-xs font-bold text-rose-600 dark:text-rose-400 hover:underline flex items-center space-x-1 cursor-pointer"
            >
              <span>Admin Portal Login</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
