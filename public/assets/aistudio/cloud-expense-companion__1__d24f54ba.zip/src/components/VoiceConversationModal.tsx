import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  X, 
  Mic, 
  MicOff, 
  Volume2, 
  Sparkles, 
  AlertCircle, 
  PhoneOff, 
  RotateCw, 
  MessageSquare, 
  Settings, 
  CheckCircle2, 
  Headphones,
  Radio,
  VolumeX
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSwitchToTextChat?: () => void;
}

interface MessageTurn {
  sender: 'user' | 'model';
  text: string;
}

export type VoiceSessionStatus = 
  | 'idle'
  | 'requesting_permission'
  | 'mic_ready'
  | 'connecting'
  | 'connected'
  | 'connection_failed'
  | 'quota_exceeded';

export const VoiceConversationModal: React.FC<Props> = ({ 
  isOpen, 
  onClose,
  onSwitchToTextChat 
}) => {
  const [sessionStatus, setSessionStatus] = useState<VoiceSessionStatus>('idle');
  const [isMuted, setIsMuted] = useState(false);
  const [transcripts, setTranscripts] = useState<MessageTurn[]>([]);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [showBrowserHelp, setShowBrowserHelp] = useState(false);
  const [fallbackMode, setFallbackMode] = useState<boolean>(false);
  const [isRecognizing, setIsRecognizing] = useState<boolean>(false);

  const wsRef = useRef<WebSocket | null>(null);
  const inputAudioCtxRef = useRef<AudioContext | null>(null);
  const outputAudioCtxRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const sourceNodeRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const activeAudioSourcesRef = useRef<AudioBufferSourceNode[]>([]);
  const isMutedRef = useRef<boolean>(false);
  const recognitionRef = useRef<any>(null);

  // Keep isMutedRef in sync with state to avoid stale closures in audio processor
  useEffect(() => {
    isMutedRef.current = isMuted;
  }, [isMuted]);

  // When modal closes, immediately terminate all streams
  useEffect(() => {
    if (!isOpen) {
      stopVoiceSession();
      setSessionStatus('idle');
      setStatusMessage(null);
      setShowBrowserHelp(false);
      setTranscripts([]);
      setFallbackMode(false);
    }
  }, [isOpen]);

  /**
   * Helper: Stop all currently playing audio chunks (handles interruptions)
   */
  const stopAllAudioPlayback = useCallback(() => {
    activeAudioSourcesRef.current.forEach((src) => {
      try {
        src.stop();
        src.disconnect();
      } catch {}
    });
    activeAudioSourcesRef.current = [];
    if (outputAudioCtxRef.current) {
      nextStartTimeRef.current = outputAudioCtxRef.current.currentTime;
    }
  }, []);

  /**
   * Complete clean teardown of all hardware and network resources
   */
  const stopVoiceSession = useCallback((resetStatusToIdle = true) => {
    // 1. Stop Speech Recognition if fallback mode was active
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
      recognitionRef.current = null;
    }
    setIsRecognizing(false);

    // 2. Stop speech synthesis playback if active
    if (typeof window !== 'undefined' && window.speechSynthesis) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }

    // 3. Stop currently scheduled output audio sources
    stopAllAudioPlayback();

    // 4. Close WebSocket
    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch {}
      wsRef.current = null;
    }

    // 5. Disconnect audio capture nodes
    if (scriptProcessorRef.current) {
      try {
        scriptProcessorRef.current.disconnect();
      } catch {}
      scriptProcessorRef.current = null;
    }

    if (sourceNodeRef.current) {
      try {
        sourceNodeRef.current.disconnect();
      } catch {}
      sourceNodeRef.current = null;
    }

    // 6. Stop all hardware microphone tracks
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch {}
      });
      mediaStreamRef.current = null;
    }

    // 7. Close Audio Contexts
    if (inputAudioCtxRef.current && inputAudioCtxRef.current.state !== 'closed') {
      try {
        inputAudioCtxRef.current.close();
      } catch {}
      inputAudioCtxRef.current = null;
    }

    if (outputAudioCtxRef.current && outputAudioCtxRef.current.state !== 'closed') {
      try {
        outputAudioCtxRef.current.close();
      } catch {}
      outputAudioCtxRef.current = null;
    }

    setIsMuted(false);
    isMutedRef.current = false;

    if (resetStatusToIdle) {
      setSessionStatus('idle');
      setStatusMessage(null);
    }
  }, [stopAllAudioPlayback]);

  /**
   * Downsamples input audio from native hardware rate (e.g. 48000Hz) to 16000Hz PCM
   */
  const downsampleTo16000 = (input: Float32Array, inputSampleRate: number): Float32Array => {
    if (inputSampleRate === 16000) return input;
    const ratio = inputSampleRate / 16000;
    const newLength = Math.round(input.length / ratio);
    const result = new Float32Array(newLength);
    let offsetResult = 0;
    let offsetInput = 0;
    while (offsetResult < result.length) {
      const nextOffsetInput = Math.round((offsetResult + 1) * ratio);
      let accum = 0;
      let count = 0;
      for (let i = offsetInput; i < nextOffsetInput && i < input.length; i++) {
        accum += input[i];
        count++;
      }
      result[offsetResult] = count > 0 ? accum / count : 0;
      offsetResult++;
      offsetInput = nextOffsetInput;
    }
    return result;
  };

  const float32ToPCM16 = (float32Array: Float32Array): ArrayBuffer => {
    const buffer = new ArrayBuffer(float32Array.length * 2);
    const view = new DataView(buffer);
    for (let i = 0; i < float32Array.length; i++) {
      const s = Math.max(-1, Math.min(1, float32Array[i]));
      view.setInt16(i * 2, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    }
    return buffer;
  };

  const arrayBufferToBase64 = (buffer: ArrayBuffer): string => {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  };

  /**
   * Play audio chunks streamed back from Gemini Live (24kHz PCM output)
   */
  const playPCMChunk = useCallback((base64Audio: string) => {
    try {
      if (!outputAudioCtxRef.current || outputAudioCtxRef.current.state === 'closed') {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        outputAudioCtxRef.current = new AudioContextClass({ sampleRate: 24000 });
      }
      const ctx = outputAudioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      const raw = window.atob(base64Audio);
      const bytes = new Uint8Array(raw.length);
      for (let i = 0; i < raw.length; i++) {
        bytes[i] = raw.charCodeAt(i);
      }

      // Safe 16-bit alignment check (prevent RangeError)
      const sampleCount = Math.floor(raw.length / 2);
      if (sampleCount === 0) return;

      const pcm16 = new Int16Array(bytes.buffer, 0, sampleCount);
      const float32 = new Float32Array(pcm16.length);
      for (let i = 0; i < pcm16.length; i++) {
        float32[i] = pcm16[i] / 32768.0;
      }

      const audioBuffer = ctx.createBuffer(1, float32.length, 24000);
      audioBuffer.getChannelData(0).set(float32);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);

      const currentTime = ctx.currentTime;
      if (nextStartTimeRef.current < currentTime) {
        nextStartTimeRef.current = currentTime;
      }

      source.start(nextStartTimeRef.current);
      nextStartTimeRef.current += audioBuffer.duration;

      // Keep track of active sources for interruption handling
      activeAudioSourcesRef.current.push(source);
      source.onended = () => {
        activeAudioSourcesRef.current = activeAudioSourcesRef.current.filter((s) => s !== source);
      };
    } catch (err) {
      console.error('PCM playback error:', err);
    }
  }, []);

  /**
   * Configure audio input capture pipeline
   */
  const setupAudioPipeline = (stream: MediaStream, ws: WebSocket) => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const inputCtx = new AudioContextClass();
      inputAudioCtxRef.current = inputCtx;

      // Resume AudioContext if suspended by browser autoplay policy
      if (inputCtx.state === 'suspended') {
        inputCtx.resume();
      }

      const source = inputCtx.createMediaStreamSource(stream);
      sourceNodeRef.current = source;

      // ScriptProcessor with buffer size 4096
      const processor = inputCtx.createScriptProcessor(4096, 1, 1);
      scriptProcessorRef.current = processor;

      source.connect(processor);
      processor.connect(inputCtx.destination);

      processor.onaudioprocess = (e) => {
        if (isMutedRef.current) return;
        const inputData = e.inputBuffer.getChannelData(0);

        // Downsample to 16kHz
        const downsampled = downsampleTo16000(inputData, inputCtx.sampleRate);
        const pcm16 = float32ToPCM16(downsampled);
        const base64 = arrayBufferToBase64(pcm16);

        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'audio', audio: base64 }));
        }
      };
    } catch (pipelineErr) {
      console.error('Audio pipeline configuration error:', pipelineErr);
      setSessionStatus('connection_failed');
      setStatusMessage('Failed to initialize audio processor. Please click Retry.');
    }
  };

  /**
   * Handle server errors (e.g. 429 quota exhaustion or connection failures)
   */
  const handleServerVoiceError = (msg: any) => {
    stopVoiceSession(false);

    const isQuota = 
      msg.errorType === 'quota_exceeded' || 
      String(msg.message).includes('usage limit') || 
      String(msg.message).includes('429') ||
      String(msg.message).includes('RESOURCE_EXHAUSTED');

    if (isQuota) {
      setSessionStatus('quota_exceeded');
      setStatusMessage('Live streaming quota is temporarily reached. You can switch to Speech-to-Speech mode below to continue speaking with Gemini!');
    } else {
      setSessionStatus('connection_failed');
      setStatusMessage(msg.message || 'Voice service encountered an error. Please click Retry Connection.');
    }
  };

  /**
   * Start Live Voice Session (Primary Mode: gemini-3.8-live)
   */
  const startVoiceSession = async () => {
    stopVoiceSession();
    setStatusMessage(null);
    setShowBrowserHelp(false);
    setSessionStatus('requesting_permission');

    // 1. Verify Browser Support
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setSessionStatus('connection_failed');
      setStatusMessage('Microphone input is not supported in this browser. Please use Chrome, Edge, Safari, or Firefox.');
      return;
    }

    // 2. Request Microphone Access with resilient constraints
    let stream: MediaStream;
    try {
      try {
        // Preferred high quality voice constraints
        stream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          }
        });
      } catch (errConstraint) {
        // Fallback to basic audio constraint if constraints failed
        console.warn('Constraint getUserMedia failed, falling back to simple audio constraint:', errConstraint);
        stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      }

      // Verify active audio track received
      const audioTracks = stream.getAudioTracks();
      if (!audioTracks || audioTracks.length === 0 || audioTracks[0].readyState !== 'live') {
        throw new Error('No active audio track received from microphone device.');
      }

      mediaStreamRef.current = stream;
      setIsMuted(false);
      isMutedRef.current = false;
      setSessionStatus('mic_ready');
    } catch (micErr: any) {
      console.warn('Microphone acquisition error:', micErr);
      const name = micErr?.name || '';
      setSessionStatus('connection_failed');

      if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
        setStatusMessage('Microphone permission was denied. Please allow microphone access in your browser settings and click Retry Connection.');
        setShowBrowserHelp(true);
      } else if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
        setStatusMessage('No microphone was detected. Please plug in or connect an audio input device.');
      } else if (name === 'NotReadableError' || name === 'TrackStartError') {
        setStatusMessage('Your microphone is busy or locked by another app (e.g. Zoom, Teams, or another browser tab). Please release it and retry.');
      } else {
        setStatusMessage('Could not access microphone. Please verify device permissions and try again.');
        setShowBrowserHelp(true);
      }
      return;
    }

    // 3. Connect to Gemini Live API WebSocket
    setSessionStatus('connecting');

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/live`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('Gemini Live WebSocket opened');
      };

      ws.onmessage = async (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'status' && msg.status === 'connected') {
            setupAudioPipeline(stream, ws);
            setSessionStatus('connected');
            setStatusMessage(null);
          } else if (msg.type === 'audio' && msg.audio) {
            playPCMChunk(msg.audio);
          } else if (msg.type === 'interrupted') {
            // User interrupted model speaking: stop all current playback immediately
            stopAllAudioPlayback();
          } else if (msg.type === 'user_transcription' && msg.text) {
            setTranscripts(prev => [...prev, { sender: 'user', text: msg.text }]);
          } else if (msg.type === 'model_transcription' && msg.text) {
            setTranscripts(prev => {
              const last = prev[prev.length - 1];
              if (last && last.sender === 'model') {
                return [...prev.slice(0, -1), { sender: 'model', text: last.text + ' ' + msg.text }];
              }
              return [...prev, { sender: 'model', text: msg.text }];
            });
          } else if (msg.type === 'error') {
            handleServerVoiceError(msg);
          }
        } catch (parseErr) {
          console.error('Error handling live message:', parseErr);
        }
      };

      ws.onerror = (wsErr) => {
        console.error('WebSocket connection error:', wsErr);
        setSessionStatus('connection_failed');
        setStatusMessage('Unable to connect to the Live Voice server. Click Retry or use Speech Mode below.');
        stopVoiceSession(false);
      };

      ws.onclose = () => {
        setSessionStatus((curr) => {
          if (curr === 'connected') {
            setStatusMessage('Voice session ended.');
            return 'idle';
          }
          return curr;
        });
      };
    } catch (err: any) {
      console.error('Failed to initiate Live Voice session:', err);
      setSessionStatus('connection_failed');
      setStatusMessage('Connection to Live Voice server failed. Please click Retry.');
      stopVoiceSession(false);
    }
  };

  /**
   * Toggle hardware mic track status
   */
  const handleToggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    isMutedRef.current = nextMuted;

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = !nextMuted;
      });
    }
  };

  /**
   * Fallback Speech-to-Speech Mode:
   * Uses browser SpeechRecognition + Gemini Chat (/api/chat) + speechSynthesis
   * Works 100% reliably even when Live API Free Tier quota is reached.
   */
  const startFallbackSpeechMode = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Your browser does not support Web Speech Recognition. Please use Google Chrome or Edge.');
      return;
    }

    stopVoiceSession();
    setFallbackMode(true);
    setSessionStatus('connected');
    setStatusMessage('Speech Mode Active: Speak your question clearly, and Gemini will reply with voice.');

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsRecognizing(true);
      };

      recognition.onresult = async (event: any) => {
        const spokenText = event.results[0][0].transcript;
        if (!spokenText) return;

        setTranscripts(prev => [...prev, { sender: 'user', text: spokenText }]);
        setIsRecognizing(false);
        setStatusMessage('Gemini is formulating financial advice...');

        try {
          const res = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              messages: [{ role: 'user', content: spokenText }],
              role: 'advisor'
            })
          });

          const data = await res.json();
          const reply = data.text || 'I analyzed your query. How else may I assist your financial planning?';
          setTranscripts(prev => [...prev, { sender: 'model', text: reply }]);
          setStatusMessage('Speaking response...');

          // Spoken output via browser speech synthesis
          if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
            const utterance = new SpeechSynthesisUtterance(reply.replace(/[*#]/g, ''));
            utterance.rate = 1.05;
            utterance.pitch = 1.0;
            utterance.onend = () => {
              setStatusMessage('Tap "Speak Again" whenever you want to ask another question.');
            };
            window.speechSynthesis.speak(utterance);
          }
        } catch (err) {
          console.error('Chat fallback error:', err);
          setStatusMessage('Could not retrieve answer. Please try again.');
        }
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsRecognizing(false);
        if (event.error === 'not-allowed') {
          setStatusMessage('Microphone permission was denied for speech recognition.');
        } else {
          setStatusMessage('Did not catch your voice. Tap "Speak Again" to try again.');
        }
      };

      recognition.onend = () => {
        setIsRecognizing(false);
      };

      recognitionRef.current = recognition;
      recognition.start();
    } catch (e) {
      console.error('Failed to start speech recognition:', e);
      setStatusMessage('Speech recognition failed to start. Please check microphone permissions.');
    }
  };

  if (!isOpen) return null;

  return (
    <div id="voice-conversation-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 max-w-lg w-full shadow-2xl flex flex-col max-h-[90vh]">
        {/* Top Header */}
        <div className="flex items-center justify-between pb-3.5 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-2xl bg-teal-500/10 text-teal-600 dark:text-teal-400">
              <Headphones className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                  Live Voice Assistant
                </h3>
                <span className="px-2 py-0.5 text-[10px] font-bold bg-teal-100 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 rounded-full border border-teal-200 dark:border-teal-800">
                  {fallbackMode ? 'Speech-to-Speech' : 'gemini-3.8-live'}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Spoken interactive personal finance advisor
              </p>
            </div>
          </div>

          <button
            onClick={() => { stopVoiceSession(); onClose(); }}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            title="Close voice modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* State Banner / Error Alert */}
        {statusMessage && (
          <div className={`my-3 p-3.5 rounded-2xl border text-xs space-y-2 ${
            sessionStatus === 'quota_exceeded'
              ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900/60 text-amber-900 dark:text-amber-200'
              : sessionStatus === 'connection_failed'
              ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900/60 text-rose-800 dark:text-rose-200'
              : 'bg-teal-50 dark:bg-teal-950/40 border-teal-200 dark:border-teal-900/60 text-teal-900 dark:text-teal-200'
          }`}>
            <div className="flex items-start space-x-2.5">
              <AlertCircle className={`w-4 h-4 shrink-0 mt-0.5 ${
                sessionStatus === 'quota_exceeded' ? 'text-amber-600' :
                sessionStatus === 'connection_failed' ? 'text-rose-600' : 'text-teal-600'
              }`} />
              <div className="flex-1">
                <span className="font-bold block mb-0.5">
                  {sessionStatus === 'quota_exceeded' ? 'Notice: Streaming Limit Reached' :
                   sessionStatus === 'connection_failed' ? 'Microphone / Connection Notice' : 'Session Status'}
                </span>
                <p className="text-[11px] leading-relaxed">{statusMessage}</p>
              </div>
            </div>

            {/* Quick Actions inside error alert */}
            <div className="flex items-center gap-2 pt-1 flex-wrap">
              <button
                type="button"
                onClick={startVoiceSession}
                className="px-3 py-1.5 rounded-xl font-bold bg-teal-600 hover:bg-teal-700 text-white text-[11px] transition-colors cursor-pointer flex items-center space-x-1 shadow-2xs"
              >
                <RotateCw className="w-3 h-3" />
                <span>Retry Connection</span>
              </button>

              {/* Instant Speech Mode button */}
              <button
                type="button"
                onClick={startFallbackSpeechMode}
                className="px-3 py-1.5 rounded-xl font-bold bg-amber-600 hover:bg-amber-700 text-white text-[11px] transition-colors cursor-pointer flex items-center space-x-1 shadow-2xs"
                title="Use browser speech recognition with Gemini"
              >
                <Mic className="w-3 h-3" />
                <span>Use Speech-to-Speech Mode</span>
              </button>

              {onSwitchToTextChat && (
                <button
                  type="button"
                  onClick={() => {
                    stopVoiceSession();
                    onClose();
                    onSwitchToTextChat();
                  }}
                  className="px-3 py-1.5 rounded-xl font-bold bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 text-[11px] transition-colors cursor-pointer flex items-center space-x-1 shadow-2xs"
                >
                  <MessageSquare className="w-3 h-3 text-emerald-500" />
                  <span>Switch to Text Chat</span>
                </button>
              )}
            </div>

            {/* Browser Permission Help Steps */}
            {showBrowserHelp && (
              <div className="mt-2 pt-2 border-t border-slate-200/60 dark:border-slate-700/60 text-[11px] text-slate-600 dark:text-slate-300 space-y-1">
                <span className="font-bold flex items-center gap-1 text-slate-800 dark:text-slate-100">
                  <Settings className="w-3.5 h-3.5 text-slate-500" />
                  How to enable microphone in browser:
                </span>
                <ol className="list-decimal pl-4 space-y-0.5 text-[10px]">
                  <li>Click the <strong>padlock / site settings icon</strong> on the left side of the address bar.</li>
                  <li>Set <strong>Microphone</strong> permission to <strong>Allow</strong>.</li>
                  <li>Click <strong>Retry Connection</strong> above.</li>
                </ol>
              </div>
            )}
          </div>
        )}

        {/* Central State Waveform Display */}
        <div className="my-5 flex flex-col items-center justify-center space-y-3">
          <div className={`relative flex items-center justify-center w-28 h-28 rounded-full transition-all duration-300 ${
            sessionStatus === 'connected'
              ? isMuted
                ? 'bg-amber-500/10 ring-4 ring-amber-500/30'
                : 'bg-gradient-to-tr from-teal-500/20 via-emerald-500/30 to-teal-400/20 ring-4 ring-teal-500/30 shadow-lg shadow-teal-500/20'
              : sessionStatus === 'connecting' || sessionStatus === 'requesting_permission'
              ? 'bg-teal-500/10 ring-4 ring-teal-500/20'
              : 'bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700'
          }`}>
            {sessionStatus === 'connected' && !isMuted && (
              <div className="absolute inset-0 rounded-full bg-teal-500/15 animate-ping" />
            )}

            {sessionStatus === 'requesting_permission' ? (
              <Mic className="w-10 h-10 text-teal-600 dark:text-teal-400 animate-pulse" />
            ) : sessionStatus === 'mic_ready' ? (
              <CheckCircle2 className="w-10 h-10 text-emerald-500" />
            ) : sessionStatus === 'connecting' ? (
              <Sparkles className="w-10 h-10 text-teal-600 dark:text-teal-400 animate-spin" />
            ) : sessionStatus === 'connected' ? (
              isMuted ? (
                <MicOff className="w-10 h-10 text-amber-500" />
              ) : isRecognizing ? (
                <Radio className="w-10 h-10 text-emerald-500 animate-pulse" />
              ) : (
                <Volume2 className="w-10 h-10 text-teal-600 dark:text-teal-400 animate-bounce" />
              )
            ) : (
              <Mic className="w-10 h-10 text-slate-400" />
            )}
          </div>

          {/* Explicit Status Indicator (Required by specification) */}
          <div className="text-center space-y-1">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block">
              {sessionStatus === 'idle' && 'Ready to Start Voice Conversation'}
              {sessionStatus === 'requesting_permission' && 'Requesting Microphone Permission...'}
              {sessionStatus === 'mic_ready' && 'Microphone Ready — Establishing AI Connection...'}
              {sessionStatus === 'connecting' && 'Connecting to AI Assistant...'}
              {sessionStatus === 'connected' && (
                isMuted
                  ? 'Microphone Muted'
                  : fallbackMode
                  ? isRecognizing ? 'Listening to your voice... Speak now' : 'Speech Mode Ready • Tap Speak'
                  : 'Voice Connected • Speak naturally'
              )}
              {sessionStatus === 'connection_failed' && 'Connection Failed'}
              {sessionStatus === 'quota_exceeded' && 'Live Quota Limit Reached'}
            </span>

            {/* Current State Pill */}
            <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
              <span className={`w-1.5 h-1.5 rounded-full ${
                sessionStatus === 'connected' ? 'bg-emerald-500 animate-pulse' :
                sessionStatus === 'connecting' || sessionStatus === 'requesting_permission' ? 'bg-teal-500 animate-ping' :
                sessionStatus === 'connection_failed' || sessionStatus === 'quota_exceeded' ? 'bg-rose-500' : 'bg-slate-400'
              }`} />
              <span className="capitalize">{sessionStatus.replace('_', ' ')}</span>
            </div>
          </div>
        </div>

        {/* Live Conversation Transcript History */}
        <div className="flex-1 bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 rounded-2xl p-3.5 overflow-y-auto space-y-2 text-xs min-h-[130px] max-h-[200px] scrollbar-thin">
          {transcripts.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 text-center px-4 py-4 space-y-1">
              <Sparkles className="w-5 h-5 text-slate-300 dark:text-slate-600 mb-1" />
              <span className="text-xs font-semibold">Live spoken transcriptions appear here</span>
              <span className="text-[11px]">Ask: "What was my biggest expense this month?" or "How can I cut food spending?"</span>
            </div>
          ) : (
            transcripts.map((turn, i) => (
              <div
                key={i}
                className={`p-3 rounded-2xl text-xs max-w-[85%] ${
                  turn.sender === 'user'
                    ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white ml-auto rounded-br-xs shadow-xs'
                    : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-200 dark:border-slate-700 mr-auto rounded-bl-xs shadow-xs'
                }`}
              >
                <span className="block text-[10px] opacity-75 font-bold mb-0.5">
                  {turn.sender === 'user' ? 'You' : 'Gemini Voice'}
                </span>
                {turn.text}
              </div>
            ))
          )}
        </div>

        {/* Action Controls */}
        <div className="mt-4 pt-3.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
          {sessionStatus === 'connected' ? (
            <>
              {fallbackMode ? (
                /* Fallback Speech Mode Controls */
                <div className="w-full flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={startFallbackSpeechMode}
                    disabled={isRecognizing}
                    className={`flex-1 py-2.5 px-4 rounded-2xl text-xs font-bold flex items-center justify-center space-x-2 transition-all cursor-pointer shadow-md ${
                      isRecognizing 
                        ? 'bg-rose-600 text-white animate-pulse'
                        : 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white hover:from-emerald-700 hover:to-teal-700'
                    }`}
                  >
                    <Mic className="w-4 h-4" />
                    <span>{isRecognizing ? 'Listening... Speak Now' : 'Speak to Gemini'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => { stopVoiceSession(true); setFallbackMode(false); }}
                    className="px-4 py-2.5 text-xs font-bold text-white bg-slate-700 hover:bg-slate-800 rounded-2xl transition-colors flex items-center space-x-1.5 shadow-md cursor-pointer"
                  >
                    <PhoneOff className="w-4 h-4" />
                    <span>Exit</span>
                  </button>
                </div>
              ) : (
                /* Live Streaming Mode Controls */
                <>
                  <button
                    type="button"
                    onClick={handleToggleMute}
                    className={`px-4 py-2.5 rounded-2xl text-xs font-bold flex items-center space-x-1.5 transition-colors cursor-pointer border shadow-2xs ${
                      isMuted
                        ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-300 dark:border-amber-800'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {isMuted ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    <span>{isMuted ? 'Unmute Mic' : 'Mute Mic'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => stopVoiceSession(true)}
                    className="px-4 py-2.5 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-2xl transition-colors flex items-center space-x-1.5 shadow-md cursor-pointer active:scale-95"
                  >
                    <PhoneOff className="w-4 h-4" />
                    <span>End Voice Call</span>
                  </button>
                </>
              )}
            </>
          ) : (
            <div className="w-full flex items-center gap-2">
              <button
                type="button"
                onClick={startVoiceSession}
                disabled={sessionStatus === 'connecting' || sessionStatus === 'requesting_permission'}
                className="flex-1 py-3 text-xs font-bold text-white bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 rounded-2xl transition-all shadow-md flex items-center justify-center space-x-2 cursor-pointer active:scale-98 disabled:opacity-50"
              >
                {sessionStatus === 'connection_failed' || sessionStatus === 'quota_exceeded' ? (
                  <>
                    <RotateCw className="w-4 h-4" />
                    <span>Retry Live Connection</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    <span>
                      {sessionStatus === 'requesting_permission'
                        ? 'Requesting Microphone...'
                        : sessionStatus === 'connecting'
                        ? 'Connecting to AI...'
                        : 'Start Voice Conversation'}
                    </span>
                  </>
                )}
              </button>

              {/* Fallback Speech Mode Button when quota exceeded */}
              {(sessionStatus === 'quota_exceeded' || sessionStatus === 'connection_failed') && (
                <button
                  type="button"
                  onClick={startFallbackSpeechMode}
                  className="px-3.5 py-3 text-xs font-bold text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/60 hover:bg-amber-100 dark:hover:bg-amber-900/60 border border-amber-300 dark:border-amber-800 rounded-2xl transition-colors cursor-pointer flex items-center space-x-1.5"
                  title="Speech-to-Speech Mode"
                >
                  <Radio className="w-4 h-4 text-amber-500" />
                  <span className="hidden sm:inline">Speech Mode</span>
                </button>
              )}

              {onSwitchToTextChat && (
                <button
                  type="button"
                  onClick={() => {
                    stopVoiceSession();
                    onClose();
                    onSwitchToTextChat();
                  }}
                  className="px-3.5 py-3 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl transition-colors cursor-pointer flex items-center space-x-1.5"
                  title="Switch to Text AI Chat"
                >
                  <MessageSquare className="w-4 h-4 text-emerald-500" />
                  <span className="hidden sm:inline">Text Chat</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
