import { 
  collection, 
  doc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy, 
  setDoc 
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Expense, CategoryBudget, SavingsGoal, IncomeRecord } from '../types';

// Storage keys for offline/guest fallback
const LOCAL_EXPENSES_KEY = 'cloud_expense_companion_expenses';
const LOCAL_BUDGETS_KEY = 'cloud_expense_companion_budgets';
const LOCAL_GOALS_KEY = 'cloud_expense_companion_goals';
const LOCAL_INCOMES_KEY = 'cloud_expense_companion_incomes';

/**
 * Ensures the parent /users/{userId} document is created and populated in Firestore.
 * This ensures the Firebase Console doesn't show the italicized "This document does not exist" warning.
 */
export async function ensureUserDocument(
  userId: string, 
  email?: string | null, 
  displayName?: string | null
): Promise<void> {
  if (!userId || userId === 'guest') return;
  try {
    const userDocRef = doc(db, 'users', userId);
    await setDoc(userDocRef, {
      uid: userId,
      email: email || '',
      displayName: displayName || '',
      appName: 'Cloud Expense Companion',
      updatedAt: new Date().toISOString()
    }, { merge: true });
  } catch (err: any) {
    // Non-fatal, log warning
    console.warn('[Firestore] Could not ensure parent user document:', err?.message || err);
  }
}

// Event subscribers for Firestore sync & permission events
export interface FirestoreSyncStatus {
  action: string;
  message: string;
  isPermissionError: boolean;
  timestamp: number;
}

type FirestoreStatusCallback = (status: FirestoreSyncStatus) => void;
const statusListeners = new Set<FirestoreStatusCallback>();

export function onFirestoreSyncStatus(callback: FirestoreStatusCallback): () => void {
  statusListeners.add(callback);
  return () => {
    statusListeners.delete(callback);
  };
}

function notifyFirestoreStatus(action: string, err: any): void {
  const msg = err?.message || String(err);
  const isPermission = 
    err?.code === 'permission-denied' || 
    msg.toLowerCase().includes('permission') || 
    msg.toLowerCase().includes('insufficient') ||
    msg.toLowerCase().includes('missing');

  if (isPermission) {
    console.warn(`[Firestore Notice] Permission denied during ${action}: ${msg}. Saved locally.`);
  } else {
    console.warn(`[Firestore Notice] Operation ${action} encountered issue: ${msg}. Fallback to local storage.`);
  }

  const payload: FirestoreSyncStatus = {
    action,
    message: msg,
    isPermissionError: isPermission,
    timestamp: Date.now()
  };

  statusListeners.forEach(listener => {
    try {
      listener(payload);
    } catch {
      // ignore subscriber errors
    }
  });
}

// Initial default budgets
export const DEFAULT_BUDGETS: CategoryBudget[] = [
  { category: 'Food', monthlyLimit: 5000 },
  { category: 'Travel', monthlyLimit: 3000 },
  { category: 'Shopping', monthlyLimit: 4000 },
  { category: 'Bills', monthlyLimit: 6000 },
  { category: 'Entertainment', monthlyLimit: 2000 },
  { category: 'Fuel', monthlyLimit: 3500 },
  { category: 'Subscriptions', monthlyLimit: 1500 }
];

// Helper to read local expenses
function getStoredExpenses(): Expense[] {
  const raw = localStorage.getItem(LOCAL_EXPENSES_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

// --- EXPENSES ---
export async function getUserExpenses(userId: string | null): Promise<Expense[]> {
  const localList = getStoredExpenses();

  if (userId) {
    try {
      const colRef = collection(db, 'users', userId, 'expenses');
      const q = query(colRef, orderBy('date', 'desc'));
      const snapshot = await getDocs(q);
      const remoteList: Expense[] = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      } as Expense));

      // Combine remote items with any offline/local items not yet in Firestore
      const localPending = localList.filter(e => e.id.startsWith('exp_'));
      const combined = [...remoteList, ...localPending];

      // Update local cache
      localStorage.setItem(LOCAL_EXPENSES_KEY, JSON.stringify(combined));
      return combined;
    } catch (err: any) {
      notifyFirestoreStatus('fetch expenses', err);
    }
  }

  return localList;
}

export async function addExpense(userId: string | null, expense: Omit<Expense, 'id' | 'createdAt' | 'userId'>): Promise<Expense> {
  const newObj: Expense = {
    ...expense,
    id: `exp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId: userId || 'guest',
    createdAt: new Date().toISOString()
  };

  // Immediate local persistence (guaranteed offline & permissions fallback)
  const existing = getStoredExpenses();
  const updated = [newObj, ...existing];
  localStorage.setItem(LOCAL_EXPENSES_KEY, JSON.stringify(updated));

  if (userId) {
    try {
      // Ensure parent document exists so Firebase Console shows it populated
      await ensureUserDocument(userId);

      const colRef = collection(db, 'users', userId, 'expenses');
      const docRef = await addDoc(colRef, {
        userId,
        title: expense.title,
        amount: expense.amount,
        category: expense.category,
        date: expense.date,
        description: expense.description || '',
        createdAt: newObj.createdAt
      });
      
      // Update with the permanent Firestore ID
      const oldId = newObj.id;
      newObj.id = docRef.id;
      const synced = updated.map(e => e.id === oldId ? { ...e, id: docRef.id } : e);
      localStorage.setItem(LOCAL_EXPENSES_KEY, JSON.stringify(synced));
    } catch (err: any) {
      notifyFirestoreStatus('add expense', err);
    }
  }

  return newObj;
}

export async function updateExpense(userId: string | null, expense: Expense): Promise<void> {
  // Update local storage immediately
  const existing = getStoredExpenses();
  const updated = existing.map(e => e.id === expense.id ? expense : e);
  localStorage.setItem(LOCAL_EXPENSES_KEY, JSON.stringify(updated));

  if (userId && expense.id && !expense.id.startsWith('exp_')) {
    try {
      const docRef = doc(db, 'users', userId, 'expenses', expense.id);
      await updateDoc(docRef, {
        title: expense.title,
        amount: expense.amount,
        category: expense.category,
        date: expense.date,
        description: expense.description || ''
      });
    } catch (err: any) {
      notifyFirestoreStatus('update expense', err);
    }
  }
}

export async function deleteExpense(userId: string | null, expenseId: string): Promise<void> {
  // Update local storage immediately
  const existing = getStoredExpenses();
  const updated = existing.filter(e => e.id !== expenseId);
  localStorage.setItem(LOCAL_EXPENSES_KEY, JSON.stringify(updated));

  if (userId && !expenseId.startsWith('exp_')) {
    try {
      const docRef = doc(db, 'users', userId, 'expenses', expenseId);
      await deleteDoc(docRef);
    } catch (err: any) {
      notifyFirestoreStatus('delete expense', err);
    }
  }
}

// --- BUDGETS ---
export async function getUserBudgets(userId: string | null): Promise<CategoryBudget[]> {
  if (userId) {
    try {
      const colRef = collection(db, 'users', userId, 'budgets');
      const snapshot = await getDocs(colRef);
      if (!snapshot.empty) {
        const list = snapshot.docs.map(d => d.data() as CategoryBudget);
        localStorage.setItem(LOCAL_BUDGETS_KEY, JSON.stringify(list));
        return list;
      }
    } catch (err: any) {
      notifyFirestoreStatus('fetch budgets', err);
    }
  }

  const raw = localStorage.getItem(LOCAL_BUDGETS_KEY);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch {
      // ignore
    }
  }
  return DEFAULT_BUDGETS;
}

export async function saveCategoryBudget(userId: string | null, budget: CategoryBudget): Promise<void> {
  const existing = await getUserBudgets(null);
  const index = existing.findIndex(b => b.category === budget.category);
  let updated: CategoryBudget[];
  if (index >= 0) {
    updated = [...existing];
    updated[index] = budget;
  } else {
    updated = [...existing, budget];
  }
  localStorage.setItem(LOCAL_BUDGETS_KEY, JSON.stringify(updated));

  if (userId) {
    try {
      const docRef = doc(db, 'users', userId, 'budgets', budget.category);
      await setDoc(docRef, budget, { merge: true });
    } catch (err: any) {
      notifyFirestoreStatus('save budget', err);
    }
  }
}

// --- SAVINGS GOALS ---
export async function getUserSavingsGoals(userId: string | null): Promise<SavingsGoal[]> {
  if (userId) {
    try {
      const colRef = collection(db, 'users', userId, 'savingsGoals');
      const snapshot = await getDocs(colRef);
      const list = snapshot.docs.map(docSnap => ({
        id: docSnap.id,
        ...docSnap.data()
      } as SavingsGoal));
      localStorage.setItem(LOCAL_GOALS_KEY, JSON.stringify(list));
      return list;
    } catch (err: any) {
      notifyFirestoreStatus('fetch savings goals', err);
    }
  }

  const raw = localStorage.getItem(LOCAL_GOALS_KEY);
  if (raw) {
    try {
      return JSON.parse(raw);
    } catch {
      // ignore
    }
  }
  return [];
}

export async function addSavingsGoal(
  userId: string | null, 
  goal: Omit<SavingsGoal, 'id' | 'createdAt' | 'updatedAt' | 'userId'>
): Promise<SavingsGoal> {
  const nowStr = new Date().toISOString();
  const newGoal: SavingsGoal = {
    ...goal,
    id: `goal_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    userId: userId || 'guest',
    createdAt: nowStr,
    updatedAt: nowStr
  };

  const existing = await getUserSavingsGoals(null);
  const updated = [newGoal, ...existing];
  localStorage.setItem(LOCAL_GOALS_KEY, JSON.stringify(updated));

  if (userId) {
    try {
      const colRef = collection(db, 'users', userId, 'savingsGoals');
      const docRef = await addDoc(colRef, {
        userId,
        name: goal.name,
        targetAmount: goal.targetAmount,
        currentAmount: goal.currentAmount,
        deadline: goal.deadline,
        description: goal.description || '',
        createdAt: nowStr,
        updatedAt: nowStr
      });
      const oldId = newGoal.id;
      newGoal.id = docRef.id;
      const synced = updated.map(g => g.id === oldId ? { ...g, id: docRef.id } : g);
      localStorage.setItem(LOCAL_GOALS_KEY, JSON.stringify(synced));
    } catch (err: any) {
      notifyFirestoreStatus('add savings goal', err);
    }
  }

  return newGoal;
}

export async function updateSavingsGoal(userId: string | null, goal: SavingsGoal): Promise<void> {
  const nowStr = new Date().toISOString();
  const updatedGoal = { ...goal, updatedAt: nowStr };

  const existing = await getUserSavingsGoals(null);
  const updated = existing.map(g => g.id === goal.id ? updatedGoal : g);
  localStorage.setItem(LOCAL_GOALS_KEY, JSON.stringify(updated));

  if (userId && !goal.id.startsWith('goal_')) {
    try {
      const docRef = doc(db, 'users', userId, 'savingsGoals', goal.id);
      await updateDoc(docRef, {
        name: goal.name,
        targetAmount: goal.targetAmount,
        currentAmount: goal.currentAmount,
        deadline: goal.deadline,
        description: goal.description || '',
        updatedAt: nowStr
      });
    } catch (err: any) {
      notifyFirestoreStatus('update savings goal', err);
    }
  }
}

export async function deleteSavingsGoal(userId: string | null, goalId: string): Promise<void> {
  const existing = await getUserSavingsGoals(null);
  const updated = existing.filter(g => g.id !== goalId);
  localStorage.setItem(LOCAL_GOALS_KEY, JSON.stringify(updated));

  if (userId && !goalId.startsWith('goal_')) {
    try {
      const docRef = doc(db, 'users', userId, 'savingsGoals', goalId);
      await deleteDoc(docRef);
    } catch (err: any) {
      notifyFirestoreStatus('delete savings goal', err);
    }
  }
}

// --- INCOMES ---
export async function getUserIncomes(userId: string | null): Promise<IncomeRecord[]> {
  const raw = localStorage.getItem(LOCAL_INCOMES_KEY);
  let localList: IncomeRecord[] = [];
  if (raw) {
    try {
      localList = JSON.parse(raw);
    } catch {
      localList = [];
    }
  }

  if (userId) {
    try {
      const incomesRef = collection(db, 'users', userId, 'incomes');
      const q = query(incomesRef, orderBy('date', 'desc'));
      const snapshot = await getDocs(q);
      const firestoreList: IncomeRecord[] = [];
      snapshot.forEach(docSnap => {
        firestoreList.push({ id: docSnap.id, ...docSnap.data() } as IncomeRecord);
      });

      if (firestoreList.length > 0) {
        localStorage.setItem(LOCAL_INCOMES_KEY, JSON.stringify(firestoreList));
        return firestoreList;
      }
    } catch (err: any) {
      notifyFirestoreStatus('fetch incomes', err);
    }
  }

  // Provide initial starter incomes if completely empty
  if (localList.length === 0) {
    const defaultIncomes: IncomeRecord[] = [
      {
        id: 'inc_starter_1',
        userId: userId || 'guest',
        source: 'Primary Monthly Salary',
        amount: 65000,
        category: 'Salary',
        date: new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0],
        description: 'Monthly direct bank credit',
        createdAt: new Date().toISOString()
      },
      {
        id: 'inc_starter_2',
        userId: userId || 'guest',
        source: 'Freelance Design Retainer',
        amount: 15000,
        category: 'Freelance',
        date: new Date(new Date().getFullYear(), new Date().getMonth(), 12).toISOString().split('T')[0],
        description: 'UI/UX consultation milestone payment',
        createdAt: new Date().toISOString()
      }
    ];
    localStorage.setItem(LOCAL_INCOMES_KEY, JSON.stringify(defaultIncomes));
    return defaultIncomes;
  }

  return localList;
}

export async function addIncome(
  userId: string | null, 
  income: Omit<IncomeRecord, 'id' | 'createdAt' | 'userId'>
): Promise<IncomeRecord> {
  const newIncome: IncomeRecord = {
    ...income,
    id: `inc_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    userId: userId || 'guest',
    createdAt: new Date().toISOString()
  };

  const existing = await getUserIncomes(null);
  const updated = [newIncome, ...existing];
  localStorage.setItem(LOCAL_INCOMES_KEY, JSON.stringify(updated));

  if (userId) {
    try {
      const colRef = collection(db, 'users', userId, 'incomes');
      const docRef = await addDoc(colRef, {
        source: income.source,
        amount: income.amount,
        category: income.category,
        date: income.date,
        description: income.description || '',
        createdAt: newIncome.createdAt
      });
      newIncome.id = docRef.id;
      const reconciled = updated.map(item => item.id === newIncome.id ? newIncome : item);
      localStorage.setItem(LOCAL_INCOMES_KEY, JSON.stringify(reconciled));
    } catch (err: any) {
      notifyFirestoreStatus('save income', err);
    }
  }

  return newIncome;
}

export async function updateIncome(userId: string | null, income: IncomeRecord): Promise<void> {
  const existing = await getUserIncomes(null);
  const updated = existing.map(i => i.id === income.id ? income : i);
  localStorage.setItem(LOCAL_INCOMES_KEY, JSON.stringify(updated));

  if (userId && !income.id.startsWith('inc_')) {
    try {
      const docRef = doc(db, 'users', userId, 'incomes', income.id);
      await updateDoc(docRef, {
        source: income.source,
        amount: income.amount,
        category: income.category,
        date: income.date,
        description: income.description || ''
      });
    } catch (err: any) {
      notifyFirestoreStatus('update income', err);
    }
  }
}

export async function deleteIncome(userId: string | null, incomeId: string): Promise<void> {
  const existing = await getUserIncomes(null);
  const updated = existing.filter(i => i.id !== incomeId);
  localStorage.setItem(LOCAL_INCOMES_KEY, JSON.stringify(updated));

  if (userId && !incomeId.startsWith('inc_')) {
    try {
      const docRef = doc(db, 'users', userId, 'incomes', incomeId);
      await deleteDoc(docRef);
    } catch (err: any) {
      notifyFirestoreStatus('delete income', err);
    }
  }
}

