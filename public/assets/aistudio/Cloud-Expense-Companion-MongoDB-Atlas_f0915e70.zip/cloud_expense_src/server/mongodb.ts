import { MongoClient, Db, ObjectId } from 'mongodb';

const MONGODB_URI = process.env.MONGODB_URI || '';
const DB_NAME = process.env.MONGODB_DB_NAME || 'cloud_expense_companion';
let client: MongoClient | null = null;
let db: Db | null = null;

export function toMongoId(id: string) {
  return ObjectId.isValid(id) && String(new ObjectId(id)) === id
    ? new ObjectId(id)
    : id;
}

export async function initMongoDB() {
  if (!MONGODB_URI) {
    throw new Error('MONGODB_URI is missing. Add your MongoDB Atlas connection string to .env.');
  }
  client = new MongoClient(MONGODB_URI, { serverSelectionTimeoutMS: 10000 });
  await client.connect();
  db = client.db(DB_NAME);
  await db.command({ ping: 1 });
  console.log(`[MongoDB Atlas] Connected to database: ${DB_NAME}`);

  await Promise.all([
    db.collection('users').createIndex({ email: 1 }, { unique: true }),
    db.collection('expenses').createIndex({ userId: 1, date: -1 }),
    db.collection('incomes').createIndex({ userId: 1, date: -1 }),
    db.collection('budgets').createIndex({ userId: 1, category: 1 }, { unique: true }),
    db.collection('savings_goals').createIndex({ userId: 1 }),
  ]);
}

export function getMongoCollection(name: string) {
  if (!db) throw new Error('MongoDB Atlas is not connected. Check MONGODB_URI and network access.');
  return db.collection(name);
}

export async function getMongoStatus() {
  if (!db) throw new Error('MongoDB Atlas is not connected.');
  const names = ['users', 'expenses', 'incomes', 'budgets', 'savings_goals'];
  const collections: Record<string, number> = {};
  for (const name of names) collections[name] = await db.collection(name).countDocuments();
  return { database: DB_NAME, provider: 'MongoDB Atlas', connected: true, collections };
}

export async function closeMongoDB() {
  await client?.close();
  client = null;
  db = null;
}
