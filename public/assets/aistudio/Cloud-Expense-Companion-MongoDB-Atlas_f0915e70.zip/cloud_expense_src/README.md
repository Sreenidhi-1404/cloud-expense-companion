# Cloud Expense Companion

AI-powered personal finance tracker built with React, TypeScript, Node.js, Express, Gemini AI, and MongoDB Atlas.

## Requirements
- Node.js 20 or newer
- MongoDB Atlas cluster
- Gemini API key

## Configure MongoDB Atlas
1. Create a free cluster at https://www.mongodb.com/atlas.
2. Create a database user and add your development IP address under Network Access.
3. In Atlas, choose Connect → Drivers → Node.js and copy the connection string.
4. Copy `.env.example` to `.env` and set `MONGODB_URI`, `MONGODB_DB_NAME`, and `GEMINI_API_KEY`. Replace the URI placeholders with your real Atlas credentials.
5. Never commit `.env` or share your connection string.

## Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000. The server requires a working Atlas connection and will not silently switch to a local JSON store.

## Build
```bash
npm run build
npm start
```

## MongoDB collections
- `users`
- `expenses`
- `incomes`
- `budgets`
- `savings_goals`

The backend creates indexes for user-scoped queries and unique user emails. Use MongoDB Atlas Data Explorer to inspect these collections and documents.

## Important
The frontend calls Express API routes. MongoDB credentials are used only by the server and must never be placed in client-side code. Configure Atlas Network Access and database-user permissions appropriately before deployment.
