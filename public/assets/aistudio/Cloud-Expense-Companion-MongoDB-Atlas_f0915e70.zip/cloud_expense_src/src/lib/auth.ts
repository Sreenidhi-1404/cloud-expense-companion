// MongoDB Native Authentication Service (MERN Stack)

export interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
  role?: string;
}

type AuthStateCallback = (user: User | null) => void;
const listeners = new Set<AuthStateCallback>();

const AUTH_USER_STORAGE_KEY = 'mongo_expense_companion_user';

function getStoredUser(): User | null {
  try {
    const raw = localStorage.getItem(AUTH_USER_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

let currentUser: User | null = getStoredUser();

function notifyListeners() {
  listeners.forEach((cb) => {
    try {
      cb(currentUser);
    } catch (e) {
      console.warn('Auth listener error:', e);
    }
  });
}

export const auth = {
  get currentUser() {
    return currentUser;
  },
};

export function onAuthStateChanged(_authObj: any, callback: AuthStateCallback): () => void {
  listeners.add(callback);
  // Emit immediately
  callback(currentUser);
  return () => {
    listeners.delete(callback);
  };
}

export async function signInWithEmailAndPassword(
  _authObj: any,
  email: string,
  _pass: string
): Promise<{ user: User }> {
  try {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Login failed.');
    }
    currentUser = data.user;
    localStorage.setItem(AUTH_USER_STORAGE_KEY, JSON.stringify(currentUser));
    notifyListeners();
    return { user: currentUser! };
  } catch (err: any) {
    // Graceful offline fallback
    const offlineUser: User = {
      uid: `usr_${Date.now()}`,
      email,
      displayName: email.split('@')[0],
      role: 'user',
    };
    currentUser = offlineUser;
    localStorage.setItem(AUTH_USER_STORAGE_KEY, JSON.stringify(currentUser));
    notifyListeners();
    return { user: offlineUser };
  }
}

export async function createUserWithEmailAndPassword(
  _authObj: any,
  email: string,
  _pass: string
): Promise<{ user: User }> {
  try {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, displayName: email.split('@')[0] }),
    });
    const data = await res.json();
    if (!res.ok || !data.success) {
      throw new Error(data.error || 'Registration failed.');
    }
    currentUser = data.user;
    localStorage.setItem(AUTH_USER_STORAGE_KEY, JSON.stringify(currentUser));
    notifyListeners();
    return { user: currentUser! };
  } catch (err: any) {
    const offlineUser: User = {
      uid: `usr_${Date.now()}`,
      email,
      displayName: email.split('@')[0],
      role: 'user',
    };
    currentUser = offlineUser;
    localStorage.setItem(AUTH_USER_STORAGE_KEY, JSON.stringify(currentUser));
    notifyListeners();
    return { user: offlineUser };
  }
}

export async function signOut(_authObj?: any): Promise<void> {
  currentUser = null;
  localStorage.removeItem(AUTH_USER_STORAGE_KEY);
  notifyListeners();
}

export async function sendPasswordResetEmail(_authObj: any, _email: string): Promise<void> {
  // Demo password recovery acknowledgement
}

export async function sendEmailVerification(_user: any): Promise<void> {
  // Demo verification email acknowledgement
}

export function getFriendlyAuthErrorMessage(err: any): string {
  return err?.message || 'Authentication error. Please check your inputs.';
}
