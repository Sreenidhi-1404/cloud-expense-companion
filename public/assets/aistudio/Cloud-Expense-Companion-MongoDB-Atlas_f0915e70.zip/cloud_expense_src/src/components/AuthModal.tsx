import React, { useState } from 'react';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendPasswordResetEmail,
  sendEmailVerification,
  auth,
  getFriendlyAuthErrorMessage
} from '../lib/auth';
import { 
  X, 
  LogIn, 
  UserPlus, 
  AlertCircle, 
  CheckCircle2, 
  KeyRound, 
  ShieldCheck, 
  ShieldAlert,
  Mail, 
  Lock, 
  ArrowLeft,
  ChevronRight,
  Info
} from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onAdminSuccess?: () => void;
  initialMode?: 'signin' | 'register' | 'forgot_password' | 'admin';
}

type AuthMode = 'signin' | 'register' | 'forgot_password' | 'admin';

export const AuthModal: React.FC<Props> = ({ 
  isOpen, 
  onClose,
  onAdminSuccess,
  initialMode = 'signin' 
}) => {
  const [mode, setMode] = useState<AuthMode>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [adminPasskey, setAdminPasskey] = useState('');
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const resetMessages = () => {
    setError('');
    setSuccessMsg('');
  };

  const handleModeSwitch = (newMode: AuthMode) => {
    resetMessages();
    setMode(newMode);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    // Administrator Authentication Route
    if (mode === 'admin') {
      if (!adminPasskey) {
        setError('Please enter the administrator security credential.');
        return;
      }
      setLoading(true);
      try {
        const res = await fetch('/api/admin/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            email: email || 'admin@expensecompanion.internal', 
            passkey: adminPasskey 
          }),
        });

        const data = await res.json();
        if (!res.ok || !data.success) {
          throw new Error(data.error || 'Administrator authentication failed. Unauthorized credentials.');
        }

        sessionStorage.setItem('admin_token', data.token);
        setSuccessMsg('Administrator credentials verified.');
        setTimeout(() => {
          onClose();
          if (onAdminSuccess) {
            onAdminSuccess();
          }
        }, 600);
      } catch (err: any) {
        setError(err.message || 'Administrator authorization failed.');
      } finally {
        setLoading(false);
      }
      return;
    }

    // Normal User Registration Checks
    if (mode === 'register') {
      if (password.length < 6) {
        setError('Password must be at least 6 characters long.');
        return;
      }
      if (password !== confirmPassword) {
        setError('Passwords do not match. Please verify.');
        return;
      }
    }

    setLoading(true);

    try {
      if (mode === 'signin') {
        await signInWithEmailAndPassword(auth, email, password);
        onClose();
      } else if (mode === 'register') {
        const userCred = await createUserWithEmailAndPassword(auth, email, password);
        if (userCred.user) {
          try {
            await sendEmailVerification(userCred.user);
            setSuccessMsg('Account created successfully! A verification email was dispatched to your address.');
          } catch {
            setSuccessMsg('Account created successfully!');
          }
        }
        setTimeout(() => {
          onClose();
        }, 1500);
      } else if (mode === 'forgot_password') {
        await sendPasswordResetEmail(auth, email);
        setSuccessMsg(`Password recovery instructions dispatched to ${email}. Please check your inbox.`);
      }
    } catch (err: any) {
      setError(getFriendlyAuthErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoLogin = async (demoEmail: string) => {
    resetMessages();
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, demoEmail, 'demo123');
      onClose();
    } catch (err: any) {
      setError(getFriendlyAuthErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="auth-modal" className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-7 max-w-md w-full shadow-2xl max-h-[92vh] overflow-y-auto scrollbar-thin">
        {/* Header Bar */}
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center space-x-2.5">
            <div className={`p-2 rounded-2xl ${
              mode === 'admin' 
                ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400' 
                : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
            }`}>
              {mode === 'admin' ? <ShieldAlert className="w-5 h-5" /> : <KeyRound className="w-5 h-5" />}
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-slate-100">
                {mode === 'signin' && 'Sign In'}
                {mode === 'register' && 'Create Account'}
                {mode === 'forgot_password' && 'Reset Password'}
                {mode === 'admin' && 'Administrator Portal Login'}
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                {mode === 'signin' && 'Access and manage your personal finances securely'}
                {mode === 'register' && 'Create your personal finance account'}
                {mode === 'forgot_password' && 'Enter your email to receive recovery instructions'}
                {mode === 'admin' && 'Restricted gateway: Verified administrator role claims required'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher for Sign In / Register (Only in normal user mode) */}
        {mode !== 'forgot_password' && mode !== 'admin' && (
          <div className="flex p-1 bg-slate-100 dark:bg-slate-800/80 rounded-2xl mb-5 border border-slate-200/60 dark:border-slate-700/60">
            <button
              type="button"
              onClick={() => handleModeSwitch('signin')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                mode === 'signin'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => handleModeSwitch('register')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl transition-all cursor-pointer ${
                mode === 'register'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              Register
            </button>
          </div>
        )}

        {/* Back to sign in link for password reset or admin login */}
        {(mode === 'forgot_password' || mode === 'admin') && (
          <button
            type="button"
            onClick={() => handleModeSwitch('signin')}
            className="inline-flex items-center space-x-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 hover:underline mb-4 cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to User Sign In</span>
          </button>
        )}

        {/* Status Alerts */}
        {error && (
          <div className="mb-4 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-xs text-rose-700 dark:text-rose-300 flex items-start space-x-2.5">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-600 dark:text-rose-400" />
            <div className="space-y-1">
              <span className="font-semibold block">Authentication Notice</span>
              <p className="text-[11px] leading-relaxed">{error}</p>
            </div>
          </div>
        )}

        {successMsg && (
          <div className="mb-4 p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/60 text-xs text-emerald-800 dark:text-emerald-200 flex items-start space-x-2.5">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-600 dark:text-emerald-400" />
            <div className="space-y-1">
              <span className="font-semibold block">Success</span>
              <p className="text-[11px] leading-relaxed">{successMsg}</p>
            </div>
          </div>
        )}

        {/* 1-Click Demo Profiles (MongoDB) */}
        {mode !== 'forgot_password' && mode !== 'admin' && (
          <div className="space-y-2 mb-5 p-3.5 rounded-2xl bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/60 dark:border-emerald-900/40">
            <span className="text-[11px] font-bold text-emerald-900 dark:text-emerald-200 block mb-1.5">
              1-Click Demo Logins:
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('evaluator@kct.ac.in')}
                className="py-2 px-2.5 text-left text-[11px] font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:border-emerald-500 border border-slate-200 dark:border-slate-700 rounded-xl transition-all cursor-pointer shadow-2xs"
              >
                <span className="font-bold block text-emerald-700 dark:text-emerald-400">Faculty Demo</span>
                <span className="text-[10px] text-slate-400 truncate block">evaluator@kct.ac.in</span>
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('student.lead@college.edu')}
                className="py-2 px-2.5 text-left text-[11px] font-semibold text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 hover:border-emerald-500 border border-slate-200 dark:border-slate-700 rounded-xl transition-all cursor-pointer shadow-2xs"
              >
                <span className="font-bold block text-blue-700 dark:text-blue-400">Student Account</span>
                <span className="text-[10px] text-slate-400 truncate block">student.lead@college.edu</span>
              </button>
            </div>
          </div>
        )}

        {/* Form for Login, Register, or Admin */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {mode === 'admin' ? (
            /* Dedicated Admin Login Form */
            <div className="space-y-3.5">
              <div className="p-3 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/60 text-[11px] text-rose-800 dark:text-rose-200">
                <span className="font-bold block mb-0.5">Authorized Personnel Only:</span>
                Log in using your administrator identity and security key. Normal user accounts cannot access administrative metrics or controls.
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Administrator Email / Account ID
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="email"
                    required
                    placeholder="admin@expensecompanion.internal"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-hidden focus:ring-2 focus:ring-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Administrator Security Key / Passkey
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••••••"
                    value={adminPasskey}
                    onChange={e => setAdminPasskey(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-hidden focus:ring-2 focus:ring-rose-500 font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-bold text-white bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-700 hover:to-rose-800 rounded-2xl transition-all shadow-md cursor-pointer flex items-center justify-center space-x-2 mt-4 active:scale-98"
              >
                {loading ? (
                  <span>Verifying Credentials...</span>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4" />
                    <span>Authorize as Administrator</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            /* Normal User Form (Signin / Register / Forgot) */
            <>
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                  <input
                    type="email"
                    required
                    placeholder="you@example.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {mode !== 'forgot_password' && (
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                      Password
                    </label>
                    {mode === 'signin' && (
                      <button
                        type="button"
                        onClick={() => handleModeSwitch('forgot_password')}
                        className="text-[11px] font-semibold text-emerald-600 dark:text-emerald-400 hover:underline cursor-pointer"
                      >
                        Forgot password?
                      </button>
                    )}
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              )}

              {mode === 'register' && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3 pointer-events-none" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      className="w-full pl-9 pr-3.5 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 rounded-2xl transition-all shadow-md cursor-pointer flex items-center justify-center space-x-2 mt-4 active:scale-98"
              >
                {loading ? (
                  <span>Authenticating...</span>
                ) : mode === 'signin' ? (
                  <>
                    <LogIn className="w-4 h-4" />
                    <span>Sign In Securely</span>
                  </>
                ) : mode === 'register' ? (
                  <>
                    <UserPlus className="w-4 h-4" />
                    <span>Create Account & Verify</span>
                  </>
                ) : (
                  <>
                    <Mail className="w-4 h-4" />
                    <span>Send Password Reset Email</span>
                  </>
                )}
              </button>
            </>
          )}
        </form>

        {/* Bottom Gateway Switch to Administrator Portal */}
        {mode !== 'admin' && (
          <div className="mt-5 pt-3.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              System Administrator?
            </span>
            <button
              type="button"
              onClick={() => handleModeSwitch('admin')}
              className="text-xs font-bold text-rose-600 dark:text-rose-400 hover:underline flex items-center space-x-1 cursor-pointer"
            >
              <span>Admin Portal Login</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
