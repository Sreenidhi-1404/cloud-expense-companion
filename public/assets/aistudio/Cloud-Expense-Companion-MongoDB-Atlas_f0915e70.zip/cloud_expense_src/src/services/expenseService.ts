import { Expense, CategoryBudget, SavingsGoal, IncomeRecord } from '../types';

// Storage keys for instant offline / cache fallback
const LOCAL_EXPENSES_KEY = 'mongo_expense_companion_expenses';
const LOCAL_BUDGETS_KEY = 'mongo_expense_companion_budgets';
const LOCAL_GOALS_KEY = 'mongo_expense_companion_goals';
const LOCAL_INCOMES_KEY = 'mongo_expense_companion_incomes';

export interface FirestoreSyncStatus {
  action: string;
  message: string;
  isPermissionError: boolean;
  timestamp: number;
}

type StatusCallback = (status: FirestoreSyncStatus) => void;
const statusListeners = new Set<StatusCallback>();

export function onFirestoreSyncStatus(callback: StatusCallback): () => void {
  statusListeners.add(callback);
  return () => {
    statusListeners.delete(callback);
  };
}

export async function ensureUserDocument(
  _userId: string,
  _email?: string | null,
  _displayName?: string | null
): Promise<void> {
  // Handled automatically via MongoDB users collection
}

export const DEFAULT_BUDGETS: CategoryBudget[] = [
  { category: 'Food', monthlyLimit: 5000 },
  { category: 'Travel', monthlyLimit: 3000 },
  { category: 'Shopping', monthlyLimit: 4000 },
  { category: 'Bills', monthlyLimit: 6000 },
  { category: 'Entertainment', monthlyLimit: 2000 },
  { category: 'Fuel', monthlyLimit: 3500 },
  { category: 'Subscriptions', monthlyLimit: 1500 }
];

// --- EXPENSES (MongoDB) ---
export async function getUserExpenses(userId: string | null): Promise<Expense[]> {
  const targetUser = userId || 'guest';
  try {
    const res = await fetch(`/api/expenses?userId=${encodeURIComponent(targetUser)}`);
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        localStorage.setItem(LOCAL_EXPENSES_KEY, JSON.stringify(data.data));
        return data.data;
      }
    }
  } catch (err) {
    console.warn('[MongoDB] Fetch expenses fallback to cache:', err);
  }
  const raw = localStorage.getItem(LOCAL_EXPENSES_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function addExpense(
  userId: string | null,
  expense: Omit<Expense, 'id' | 'createdAt' | 'userId'>
): Promise<Expense> {
  const targetUser = userId || 'guest';
  try {
    const res = await fetch('/api/expenses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...expense, userId: targetUser })
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.data) {
        return data.data;
      }
    }
  } catch (err) {
    console.warn('[MongoDB] Add expense offline fallback:', err);
  }

  const fallback: Expense = {
    ...expense,
    id: `mongo_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
    userId: targetUser,
    createdAt: new Date().toISOString()
  };
  const list = await getUserExpenses(userId);
  localStorage.setItem(LOCAL_EXPENSES_KEY, JSON.stringify([fallback, ...list]));
  return fallback;
}

export async function updateExpense(userId: string | null, expense: Expense): Promise<void> {
  try {
    await fetch(`/api/expenses/${encodeURIComponent(expense.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(expense)
    });
  } catch (err) {
    console.warn('[MongoDB] Update expense offline:', err);
  }
  const list = await getUserExpenses(userId);
  const updated = list.map(e => (e.id === expense.id ? expense : e));
  localStorage.setItem(LOCAL_EXPENSES_KEY, JSON.stringify(updated));
}

export async function deleteExpense(userId: string | null, expenseId: string): Promise<void> {
  try {
    await fetch(`/api/expenses/${encodeURIComponent(expenseId)}`, {
      method: 'DELETE'
    });
  } catch (err) {
    console.warn('[MongoDB] Delete expense offline:', err);
  }
  const list = await getUserExpenses(userId);
  const updated = list.filter(e => e.id !== expenseId);
  localStorage.setItem(LOCAL_EXPENSES_KEY, JSON.stringify(updated));
}

// --- BUDGETS (MongoDB) ---
export async function getUserBudgets(userId: string | null): Promise<CategoryBudget[]> {
  const targetUser = userId || 'guest';
  try {
    const res = await fetch(`/api/budgets?userId=${encodeURIComponent(targetUser)}`);
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.data) && data.data.length > 0) {
        localStorage.setItem(LOCAL_BUDGETS_KEY, JSON.stringify(data.data));
        return data.data;
      }
    }
  } catch (err) {
    console.warn('[MongoDB] Fetch budgets offline:', err);
  }
  const raw = localStorage.getItem(LOCAL_BUDGETS_KEY);
  return raw ? JSON.parse(raw) : DEFAULT_BUDGETS;
}

export async function saveCategoryBudget(userId: string | null, budget: CategoryBudget): Promise<void> {
  const targetUser = userId || 'guest';
  try {
    await fetch('/api/budgets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...budget, userId: targetUser })
    });
  } catch (err) {
    console.warn('[MongoDB] Save budget offline:', err);
  }
  const list = await getUserBudgets(userId);
  const idx = list.findIndex(b => b.category === budget.category);
  let updated: CategoryBudget[];
  if (idx >= 0) {
    updated = [...list];
    updated[idx] = budget;
  } else {
    updated = [...list, budget];
  }
  localStorage.setItem(LOCAL_BUDGETS_KEY, JSON.stringify(updated));
}

// --- SAVINGS GOALS (MongoDB) ---
export async function getUserSavingsGoals(userId: string | null): Promise<SavingsGoal[]> {
  const targetUser = userId || 'guest';
  try {
    const res = await fetch(`/api/goals?userId=${encodeURIComponent(targetUser)}`);
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        localStorage.setItem(LOCAL_GOALS_KEY, JSON.stringify(data.data));
        return data.data;
      }
    }
  } catch (err) {
    console.warn('[MongoDB] Fetch goals offline:', err);
  }
  const raw = localStorage.getItem(LOCAL_GOALS_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function addSavingsGoal(
  userId: string | null,
  goal: Omit<SavingsGoal, 'id' | 'createdAt' | 'updatedAt' | 'userId'>
): Promise<SavingsGoal> {
  const targetUser = userId || 'guest';
  try {
    const res = await fetch('/api/goals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...goal, userId: targetUser })
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.data) {
        return data.data;
      }
    }
  } catch (err) {
    console.warn('[MongoDB] Add goal offline:', err);
  }

  const nowStr = new Date().toISOString();
  const fallback: SavingsGoal = {
    ...goal,
    id: `goal_${Date.now()}`,
    userId: targetUser,
    createdAt: nowStr,
    updatedAt: nowStr
  };
  const list = await getUserSavingsGoals(userId);
  localStorage.setItem(LOCAL_GOALS_KEY, JSON.stringify([fallback, ...list]));
  return fallback;
}

export async function updateSavingsGoal(userId: string | null, goal: SavingsGoal): Promise<void> {
  try {
    await fetch(`/api/goals/${encodeURIComponent(goal.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(goal)
    });
  } catch (err) {
    console.warn('[MongoDB] Update goal offline:', err);
  }
  const list = await getUserSavingsGoals(userId);
  const updated = list.map(g => (g.id === goal.id ? goal : g));
  localStorage.setItem(LOCAL_GOALS_KEY, JSON.stringify(updated));
}

export async function deleteSavingsGoal(userId: string | null, goalId: string): Promise<void> {
  try {
    await fetch(`/api/goals/${encodeURIComponent(goalId)}`, {
      method: 'DELETE'
    });
  } catch (err) {
    console.warn('[MongoDB] Delete goal offline:', err);
  }
  const list = await getUserSavingsGoals(userId);
  const updated = list.filter(g => g.id !== goalId);
  localStorage.setItem(LOCAL_GOALS_KEY, JSON.stringify(updated));
}

// --- INCOMES (MongoDB) ---
export async function getUserIncomes(userId: string | null): Promise<IncomeRecord[]> {
  const targetUser = userId || 'guest';
  try {
    const res = await fetch(`/api/incomes?userId=${encodeURIComponent(targetUser)}`);
    if (res.ok) {
      const data = await res.json();
      if (data.success && Array.isArray(data.data)) {
        localStorage.setItem(LOCAL_INCOMES_KEY, JSON.stringify(data.data));
        return data.data;
      }
    }
  } catch (err) {
    console.warn('[MongoDB] Fetch incomes offline:', err);
  }
  const raw = localStorage.getItem(LOCAL_INCOMES_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function addIncome(
  userId: string | null,
  income: Omit<IncomeRecord, 'id' | 'createdAt' | 'userId'>
): Promise<IncomeRecord> {
  const targetUser = userId || 'guest';
  try {
    const res = await fetch('/api/incomes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...income, userId: targetUser })
    });
    if (res.ok) {
      const data = await res.json();
      if (data.success && data.data) {
        return data.data;
      }
    }
  } catch (err) {
    console.warn('[MongoDB] Add income offline:', err);
  }
  const fallback: IncomeRecord = {
    ...income,
    id: `inc_${Date.now()}`,
    userId: targetUser,
    createdAt: new Date().toISOString()
  };
  const list = await getUserIncomes(userId);
  localStorage.setItem(LOCAL_INCOMES_KEY, JSON.stringify([fallback, ...list]));
  return fallback;
}

export async function updateIncome(userId: string | null, income: IncomeRecord): Promise<void> {
  try {
    await fetch(`/api/incomes/${encodeURIComponent(income.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(income)
    });
  } catch (err) {
    console.warn('[MongoDB] Update income offline:', err);
  }
  const list = await getUserIncomes(userId);
  const updated = list.map(i => (i.id === income.id ? income : i));
  localStorage.setItem(LOCAL_INCOMES_KEY, JSON.stringify(updated));
}

export async function deleteIncome(userId: string | null, incomeId: string): Promise<void> {
  try {
    await fetch(`/api/incomes/${encodeURIComponent(incomeId)}`, {
      method: 'DELETE'
    });
  } catch (err) {
    console.warn('[MongoDB] Delete income offline:', err);
  }
  const list = await getUserIncomes(userId);
  const updated = list.filter(i => i.id !== incomeId);
  localStorage.setItem(LOCAL_INCOMES_KEY, JSON.stringify(updated));
}
